<script setup>
import FollowingPageTemplate from './components/FollowingPageTemplate.vue'
</script>

<template>
    <FollowingPageTemplate />
</template>
