<template>
  <div class="dropdown-divider"></div>
</template>

<style scoped>
.dropdown-divider {
  height: 1px;
  background: var(--border-color-primary);
  margin: 4px 16px;
}
</style>